'use server';

/**
 * @fileOverview This file defines a Genkit flow that suggests data validation rules based on a field's name and data type.
 *
 * - suggestDataValidationRules -  A function that suggests data validation rules.
 * - SuggestDataValidationRulesInput - The input type for the suggestDataValidationRules function.
 * - SuggestDataValidationRulesOutput - The output type for the suggestDataValidationRules function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestDataValidationRulesInputSchema = z.object({
  fieldName: z.string().describe('The name of the data field.'),
  dataType: z.string().describe('The data type of the field (e.g., string, number, email, date).'),
});
export type SuggestDataValidationRulesInput = z.infer<typeof SuggestDataValidationRulesInputSchema>;

const SuggestDataValidationRulesOutputSchema = z.object({
  suggestedRules: z.array(z.string()).describe('An array of suggested validation rules for the given field.'),
});
export type SuggestDataValidationRulesOutput = z.infer<typeof SuggestDataValidationRulesOutputSchema>;

export async function suggestDataValidationRules(input: SuggestDataValidationRulesInput): Promise<SuggestDataValidationRulesOutput> {
  return suggestDataValidationRulesFlow(input);
}

const suggestDataValidationRulesPrompt = ai.definePrompt({
  name: 'suggestDataValidationRulesPrompt',
  input: {schema: SuggestDataValidationRulesInputSchema},
  output: {schema: SuggestDataValidationRulesOutputSchema},
  prompt: `You are an AI assistant that suggests data validation rules based on a field's name and data type.

  Given the following field name and data type, suggest a list of validation rules that would be appropriate.

  Field Name: {{{fieldName}}}
  Data Type: {{{dataType}}}

  Consider common validation rules such as:
  - Required
  - Minimum Length
  - Maximum Length
  - Regular Expression Pattern
  - Data Type Specific Validations (e.g., email format, date format, numeric range)

  Return the suggested validation rules as a JSON array of strings.
  `,
});

const suggestDataValidationRulesFlow = ai.defineFlow(
  {
    name: 'suggestDataValidationRulesFlow',
    inputSchema: SuggestDataValidationRulesInputSchema,
    outputSchema: SuggestDataValidationRulesOutputSchema,
  },
  async input => {
    const {output} = await suggestDataValidationRulesPrompt(input);
    return output!;
  }
);
