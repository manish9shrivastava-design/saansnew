import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-data-validation-rules.ts';