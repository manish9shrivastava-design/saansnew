import { getSchema } from '@/lib/store';
import { DataEntryForm } from '@/components/data-entry-form';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

export default function DataEntryPage() {
  const schema = getSchema();

  return (
    <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Data Entry</CardTitle>
          <CardDescription>
            Fill out the form below to add a new record. The form is dynamically generated based on the current schema.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {schema.length > 0 ? (
            <DataEntryForm schema={schema} />
          ) : (
            <div className="text-center text-muted-foreground py-8">
              No schema defined. Please define a schema first.
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
