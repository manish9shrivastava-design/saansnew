import { getSchema } from '@/lib/store';
import { SchemaEditor } from '@/components/schema-editor';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

export default function SchemaPage() {
  const schema = getSchema();

  return (
    <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
      <Card>
        <CardHeader>
          <CardTitle>Schema Definition</CardTitle>
          <CardDescription>
            Define the structure of your data. Add, edit, or remove fields that will appear in your data entry form and table.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <SchemaEditor initialSchema={schema} />
        </CardContent>
      </Card>
    </main>
  );
}
