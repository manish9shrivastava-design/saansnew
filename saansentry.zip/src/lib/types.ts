
export type DataType = 'text' | 'number' | 'email' | 'date' | 'select';

export type FieldDefinition = {
  id: string;
  name: string; // a programmatic name, e.g. "firstName"
  label: string; // a display name, e.g. "First Name"
  type: DataType;
  validations: string[]; // e.g. ["required", "minLength:2"]
  options?: string[]; // For select type
};

export type Schema = FieldDefinition[];

// Represents one row of data
export type DataRecord = {
  id: string; // unique id for the record
} & Record<string, any>;
