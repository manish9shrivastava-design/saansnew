import type { DataRecord, Schema } from './types';

// In-memory store that resets on server restart
let schema: Schema = [
  { id: '1', name: 'month', label: 'Month', type: 'text', validations: ['required'] },
  { id: '2', name: 'blockName', label: 'Name of the Block', type: 'text', validations: ['required'] },
  { id: '3', name: 'nodalOfficerName', label: 'Name of Nodal Officer Incharge of SAANS 2025-26', type: 'text', validations: ['required'] },
  { id: '4', name: 'inaugurated', label: 'Whether SAANS 2025-26 was inaugurated at District/Block level?', type: 'select', validations: ['required'], options: ['Yes', 'No'] },
  { id: '5', name: 'blocksInaugurated', label: 'Number of Blocks that inaugurated SAANS 2025-26?', type: 'number', validations: ['required', 'min:0'] },
  { id: '6', name: 'ashasTrained', label: 'No. of ASHAs trained on home visits for SAANS?', type: 'number', validations: ['required', 'min:0'] },
  { id: '7', name: 'anmsTrained', label: 'No. of ANMs trained on SAANS?', type: 'number', validations: ['required', 'min:0'] },
  { id: '8', name: 'nursingOfficersTrained', label: 'No. of Nursing Officers in PHCs, CHCs, Hospitals trained on SAANS?', type: 'number', validations: ['required', 'min:0'] },
  { id: '9', name: 'doctorsTrained', label: 'No. of Doctors trained on SAANS?', type: 'number', validations: ['required', 'min:0'] },
  { id: '10', name: 'ashasHouseVisits', label: 'No. of ASHAs that did house-to-house visits of under-five children?', type: 'number', validations: ['required', 'min:0'] },
  { id: '11', name: 'childrenAssessed', label: 'No. of under-five-children assessed by ASHAs for cough or breathing difficulty?', type: 'number', validations: ['required', 'min:0'] },
  { id: '12', name: 'childrenWithSymptoms', label: 'No. of under-five-children having symptoms and received pre-referral dose of Amoxycillin?', type: 'number', validations: ['required', 'min:0'] },
  { id: '13', name: 'childrenAdministeredAmoxycillin', label: 'No. of under-five-children administered pre-referral dose of Amoxycillin?', type: 'number', validations: ['required', 'min:0'] },
  { id: '14', name: 'childrenReferred', label: 'No. of under-five-children referred to health facility?', type: 'number', validations: ['required', 'min:0'] },
  { id: '15', name: 'housesWithRiskFactors', label: 'No. of houses with at least 1 of the risk factors (smoking, indoor air pollution, etc.)?', type: 'number', validations: ['required', 'min:0'] },
  { id: '16', name: 'homesCounselingIpc', label: 'No. of homes where counseling was done using IPC kit?', type: 'number', validations: ['required', 'min:0'] },
  { id: '17', name: 'childrenCoughSyrup', label: 'No. of under-five-children treated with cough syrup?', type: 'number', validations: ['required', 'min:0'] },
  { id: '18', name: 'childrenPneumoniaDose', label: 'No. of under-five-children treated with Pneumonia dose?', type: 'number', validations: ['required', 'min:0'] },
  { id: '19', name: 'childrenSeverePneumoniaDose', label: 'No. of under-five-children treated with Severe Pneumonia dose?', type: 'number', validations: ['required', 'min:0'] },
  { id: '20', name: 'childrenMedicalOxygen', label: 'No. of under-five-children administered medical oxygen?', type: 'number', validations: ['required', 'min:0'] },
  { id: '21', name: 'skillStationsFunctional', label: 'No. of Skill Stations functional against approval', type: 'text', validations: ['required'] },
  { id: '22', name: 'infantsPcv1', label: 'Number of infants given PCV-1 vs number of infants due for PCV-1', type: 'text', validations: ['required'] },
  { id: '23', name: 'infantsPcvBooster', label: 'Number of infants given PCV-Booster vs number of infants due for PCV-Booster', type: 'text', validations: ['required'] },
];

let data: DataRecord[] = [];

export const getSchema = (): Schema => {
  // In a real app, this would fetch from a database
  return JSON.parse(JSON.stringify(schema));
};

export const updateSchema = (newSchema: Schema): Schema => {
  // In a real app, this would save to a database
  schema = newSchema;
  // When schema changes, we should clear the data as it may no longer be valid
  data = [];
  return getSchema();
};

export const getData = (): DataRecord[] => {
  // In a real app, this would fetch from a database
  return JSON.parse(JSON.stringify(data));
};

export const addData = (record: Record<string, any>): DataRecord => {
  const newRecord: DataRecord = {
    id: `rec-${Date.now()}`,
    ...record,
  };
  data.unshift(newRecord); // Add to the beginning of the array
  return JSON.parse(JSON.stringify(newRecord));
};
